﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InventorySystem;
using System.Threading;

namespace InventorySystemTest
{
	[TestClass]
	public class InventoryManagerTests
	{

		private void InitializeInventorySystem()
		{
			StockItem firstItem = new StockItem("firstDrug", "firstTablet", DateTime.Now.AddDays(1), StockItemType.Tablet);
			InventoryManager.AddStockItem(firstItem);
		}

		private void CleanupInventorySystem()
		{
			InventoryManager.ClearInternal();
		}

		[TestMethod]
		public void InventoryManager_AddStockItem()
		{
			InitializeInventorySystem();
			int totalItems = InventoryManager.Count;
			StockItem testItem = new StockItem("testDrug", "testCapsule", DateTime.Now.AddDays(1), StockItemType.Capsule);
			InventoryManager.AddStockItem(testItem);
			Assert.AreEqual<int>(totalItems + 1, InventoryManager.Count);
			CleanupInventorySystem();
		}

		[TestMethod]
		public void InventoryManager_TakeStockItem()
		{
			InitializeInventorySystem();
			int totalItems = InventoryManager.Count;
			StockItem testItem1 = new StockItem("testDrug1", "testCapsule", DateTime.Now.AddDays(1), StockItemType.Capsule);
			StockItem testItem2 = new StockItem("testDrug2", "testTonic", DateTime.Now.AddDays(1), StockItemType.Tonic);
			InventoryManager.AddStockItem(testItem1);
			InventoryManager.AddStockItem(testItem2);
			Assert.AreEqual<int>(totalItems + 2, InventoryManager.Count);
			Assert.AreSame(testItem1, InventoryManager.TakeStockItem("testCapsule"));
			CleanupInventorySystem();
		}

		[TestMethod]
		public void InventoryManager_ItemTakenNotification()
		{
			InitializeInventorySystem();
			string takenLabel = string.Empty;

			InventoryManager.StockItemTakenHandler handler = null;
			handler = (takenItem) =>
			{
				takenLabel = takenItem.SkuLabel;
			};

			// Attach the anonymous handler
			InventoryManager.AttachTakenItemHandler(handler);

			StockItem testItem1 = new StockItem("testDrug1", "testCapsule", DateTime.Now.AddDays(1), StockItemType.Capsule);
			StockItem testItem2 = new StockItem("testDrug2", "testTonic", DateTime.Now.AddDays(1), StockItemType.Tonic);
			InventoryManager.AddStockItem(testItem1);
			InventoryManager.AddStockItem(testItem2);

			// do the testing of event now..

			Assert.AreSame(testItem1, InventoryManager.TakeStockItem("testCapsule"));
			Thread.Sleep(2 * 1000);
			Assert.AreEqual(testItem1.SkuLabel, takenLabel, false);

			// Detach the anonymous handler
			InventoryManager.AttachTakenItemHandler(handler);

			CleanupInventorySystem();
		}

		[TestMethod]
		public void InventoryManager_ItemExpiredNotification()
		{
			InitializeInventorySystem();
			string expiredLabel = string.Empty;

			InventoryManager.StockItemExpiredHandler handler = null;
			handler = (expiredItem) =>
			{
				expiredLabel = expiredItem.SkuLabel;
			};

			// Attach the anonymous handler
			InventoryManager.AttachExpiredItemHandler(handler);

			StockItem testItem1 = new StockItem("testDrug1", "testCapsule", DateTime.Now.AddDays(1), StockItemType.Capsule);
			StockItem testItem2 = new StockItem("testDrug2", "testTonic", DateTime.Now.AddSeconds(3), StockItemType.Tonic);
			InventoryManager.AddStockItem(testItem1);
			InventoryManager.AddStockItem(testItem2);

			// do the testing of event now..

			Thread.Sleep(5 * 1000);
			Assert.AreEqual(testItem2.SkuLabel, expiredLabel, false);

			// Detach the anonymous handler
			InventoryManager.AttachExpiredItemHandler(handler);

			CleanupInventorySystem();
		}

	}
}

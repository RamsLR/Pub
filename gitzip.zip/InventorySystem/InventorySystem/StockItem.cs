﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventorySystem
{
	public enum StockItemType
	{
		Tablet,
		Capsule,
		Tonic,
		Vaccine
	}

	public class StockItem
	{
		private string name;
		private string skuLabel;
		private DateTime expiryTime;
		private StockItemType type;

		private StockItem()
		{

		}

		public StockItem(string name, string label, DateTime expiryTime, StockItemType type)
		{
			this.Name = name;
			this.SkuLabel = label;
			this.ExpiryTime = expiryTime;
			this.Type = type;
		}

		public string Name
		{
			get
			{
				return name;
			}

			set
			{
				name = value;
			}
		}

		public string SkuLabel
		{
			get
			{
				return skuLabel;
			}

			set
			{
				ThrowIf.Argument.IsNullOrEmptyString(value, "StockItem.SkuLabel");
				skuLabel = value;
			}
		}

		public DateTime ExpiryTime
		{
			get
			{
				return expiryTime;
			}

			set
			{
				expiryTime = value;
			}
		}

		public StockItemType Type
		{
			get
			{
				return type;
			}

			set
			{
				type = value;
			}
		}
	}
}

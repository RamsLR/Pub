﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("InventorySystemTest")]

namespace InventorySystem
{
    public sealed class InventoryManager
	{
		const int ExpiryCheckTimerInterval = 1 * 1000; // 1 second.

		private ConcurrentDictionary<string, StockItem> stockItemsDb;
		private Timer expiryCheckTimer;

		public delegate void StockItemTakenHandler(StockItem takenItem);
		public delegate void StockItemExpiredHandler(StockItem expiredItem);

		public event StockItemTakenHandler StockItemTaken;
		public event StockItemExpiredHandler StockItemExpired;

		// static singleton pattern is used here..
		private static readonly InventoryManager onlyInstance = new InventoryManager();

		private static InventoryManager Current
		{
			get
			{
				return onlyInstance;
			}
		}
		private InventoryManager()
		{
			stockItemsDb = new ConcurrentDictionary<string, StockItem>();
			expiryCheckTimer = new Timer(ExpiryCheckTimerInterval);
			expiryCheckTimer.Elapsed += ExpiryCheckTimer_Elapsed;
		}

		private void ExpiryCheckTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			DateTime timeNow = DateTime.Now;
			foreach (var item in stockItemsDb.Where(item => timeNow > item.Value.ExpiryTime))
			{
				StockItemExpired?.Invoke(item.Value);
			}
		}

		/// <summary>
		/// Public methods listed here - conventionally they could be at the top of this file?
		/// </summary>

		private void addStockItem(StockItem stockItem)
		{
			ThrowIf.Argument.IsNull(stockItem, "StockItem");
			if (!stockItemsDb.TryAdd(stockItem.SkuLabel, stockItem))
			{
				throw new InvalidOperationException("Cannot add StockItem - it already exists for key:" + stockItem.SkuLabel);
			}
			expiryCheckTimer.Enabled = (stockItemsDb.Count > 0);
		}

		private StockItem takeStockItem(string skuLabel)
		{
			ThrowIf.Argument.IsNullOrEmptyString(skuLabel, "skuLabel");

			StockItem takenItem;
			stockItemsDb.TryRemove(skuLabel, out takenItem);
			if (takenItem != null)
			{
				expiryCheckTimer.Enabled = (stockItemsDb.Count > 0);
				// notify via the taken event 
				StockItemTaken?.Invoke(takenItem);
			}

			return takenItem;
		}

		// All public properties/methods are below this line..

		static public int Count
		{
			get
			{
				return Current.stockItemsDb.Count;
			}
		}

		static public void AddStockItem(StockItem stockItem)
		{
			Current.addStockItem(stockItem);
		}

		static public StockItem TakeStockItem(string skuLabel)
		{
			return Current.takeStockItem(skuLabel);
		}

		static public void AttachTakenItemHandler(StockItemTakenHandler handler)
		{
			Current.StockItemTaken += handler;
		}

		static public void AttachExpiredItemHandler(StockItemExpiredHandler handler)
		{
			Current.StockItemExpired += handler;
		}

		static public void DetachTakenItemHandler(StockItemTakenHandler handler)
		{
			Current.StockItemTaken -= handler;
		}

		static public void DetachExpiredItemHandler(StockItemExpiredHandler handler)
		{
			Current.StockItemExpired -= handler;
		}

		/// <summary>
		/// For Unit testing purpose ONLY!
		/// </summary>
		internal static void ClearInternal()
		{
			Current.stockItemsDb.Clear();
			Current.expiryCheckTimer.Enabled = false;
		}

	}
}
